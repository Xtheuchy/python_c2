Mi_Nombre = "Juan Alberto" #Se define una cadena utilizando comillas dobles
Mi_Apellido = 'Robles Alcantara'#Se define una cadena con comillas simples
#Mostrar el contenido de las variables 
print(Mi_Nombre)
print(Mi_Apellido)
