Mi_Nombre = "Juan Alberto" 
Mi_Apellido = 'Robles Alcantara'
#Concatenamos las cadenas
Nombre_completo = Mi_Nombre + " " + Mi_Apellido
print(Nombre_completo) #Mostramos en consola la variable Nombre_completo
