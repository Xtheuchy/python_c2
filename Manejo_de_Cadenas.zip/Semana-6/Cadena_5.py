Pais = "Perú"
print("Perú tiene " + str(len(Pais)) + " Caracteres")
Pais = "Bolivia"
print("Bolivia tiene " + str(len(Pais)) + " Caracteres")
Pais = "Ecuador"
print("Ecuador tiene " + str(len(Pais)) + " Caracteres")
Pais = "Argentina"
print("Argentina tiene " + str(len(Pais)) + " Caracteres")
pais = "Metodos para cadena de caracteres"
print("El tema tiene " + str(len(pais)) + " Caracteres")