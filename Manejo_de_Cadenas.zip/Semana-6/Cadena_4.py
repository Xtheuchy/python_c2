Datos_Completos = "Juan Alberto \n"
Datos_Completos += "Apellidos: Robles alcantara \n"
Datos_Completos += "Edad: 28 años \n"
Datos_Completos += "DNI : 75854565 \n"
Datos_Completos += "Direccion : Av. Javir prado este nº 1256 \n"
Datos_Completos += "Profesion : Docente Zegel"
print(Datos_Completos)