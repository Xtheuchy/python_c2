Mi_Nombre = "Juan Alberto" 
Mi_Apellido = 'Robles Alcantara'
#Concatenamos las cadenas y agregamos un espacio entre las dos variables
Nombre_completo = Mi_Nombre + " " + Mi_Apellido
print((Nombre_completo + "\n") * 5) #Mostrar el contendio de la variable : Nombre_Completo multiplicado por 5 con saltos de linea

