import math
def Metodo_Seno(a):
    return math.sin(a)
def Metodo_Coseno(a):
    return math.cos(a)
def Metodo_Raiz(a):
    return math.sqrt(a)
def Metodo_Factorial(a):
    return math.factorial(a)
def Metodo_imprimir_Avanzados(N):
    print("Seno            : ",Metodo_Seno(N))
    print("Coseno          : ",Metodo_Coseno(N))
    print("Raiz            : ",Metodo_Raiz(N))
    print("Factorial       : ",Metodo_Factorial(N))