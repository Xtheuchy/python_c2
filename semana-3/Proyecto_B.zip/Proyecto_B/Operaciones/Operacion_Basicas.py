def Metodo_Suma(A,B):
    return A+B
def Metodo_Resta(A,B):
    return A-B
def Metodo_Multiplica(A,B):
    return A*B
def Metodo_Divide(A,B):
    return A/B
def imprimir_Basicos(A,B):
    print("Suma           : ",Metodo_Suma(A,B))
    print("Resta          : ",Metodo_Resta(A,B))
    print("Multiplicación : ",Metodo_Multiplica(A,B))
    print("División       : ",Metodo_Divide(A,B))
