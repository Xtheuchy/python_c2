def Metodo_LeerA():
    return float(input("Ingrese A: "))
def Metodo_LeerB():
    return float(input("Ingrese B: "))
def Metodo_Leer_a():
    return int(input("Ingrese a: "))