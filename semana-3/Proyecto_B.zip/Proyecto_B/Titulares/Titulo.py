#Mensaje en pantalla
def Metodo_titulo(msj):
    print("=====================")
    print(msj)
    print("=====================")
    