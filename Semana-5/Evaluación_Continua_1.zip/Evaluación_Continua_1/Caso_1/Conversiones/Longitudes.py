#Creamos funciones para las conversiones
def metros_a_kilometros(metros):
    kilometros = metros * 0.001
    return kilometros
def kilometros_a_metros(kilometros):
    metros=kilometros * 1000
    return metros
def centimetros_a_metros(centimetros):
    metros = centimetros * 0.01
    return metros
def metros_a_centimetros(metros):
    centimetros = metros * 100
    return centimetros
#Retornamos los resultados  